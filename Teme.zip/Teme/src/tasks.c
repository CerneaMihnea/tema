#include "functional.h"
#include "tasks.h"
#include "tests.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/*void reverse_elem(void *element)
{
	int *temp = malloc(sizeof(int));
	memcpy(temp,(int *)element,sizeof(int));
	memcpy((int *)element,(int *)(element)+sizeof(int),sizeof(int));
	memcpy((int *)(element)+sizeof(int),temp,sizeof(int));
	free(temp);
	
}*/

void functie_1(void *poz, void *element)
{
	int *valoare = (int *)poz;
	int *adr_elem = (int *)element;
	int *adr_elem_ultim = (int *)element+*valoare*2;
	int aux = *adr_elem;
	*adr_elem = *adr_elem_ultim;
	*adr_elem_ultim = aux;
	(*valoare)--;
}

void functie_1_impar(void *poz, void *element)
{
	int *valoare = (int *)poz;
	int *adr_elem = (int *)element;
	int *adr_elem_ultim = (int *)element+*valoare*2-1;
	int aux = *adr_elem;
	*adr_elem = *adr_elem_ultim;
	*adr_elem_ultim = aux;
	(*valoare)--;
}


array_t reverse(array_t list) {
	int val = list.len -1;
	int lungime_init = list.len;
	if(val%2  == 0)
	{
		int aux = *(int *)list.data;
		*(int *)list.data = *(int *)(list.data+val*list.elem_size);
		*(int *)(list.data + val*list.elem_size) = aux;
		int *adr_aux = (int *)(list.data);
		val-=2;
		val/=2;
		list.len = val;
		list.data  = adr_aux+1;
		reduce(functie_1,&val,list); 
		list.data = adr_aux;
		list.len =  lungime_init;
	}
	else if(val % 2 == 1)
	{
		val=val/2+val%2;
		list.len = val;
		reduce(functie_1_impar,&val,list);
		list.len =  lungime_init;
	}
	return list;
}


void functie_2(void *element , void **componente)
{
	number_t *num = (number_t *)element;
	num->integer_part = *(int*)componente[0];
	num->fractional_part = *(int *)componente[1];
	num->string = malloc(100);
	sprintf(num->string,"%d.%d",num->integer_part,num->fractional_part);
}

void destructor(void *p)
{
	number_t *elem = (number_t *)p;
	if(elem->string!=NULL)
	{
		free(elem->string);
		elem->string=NULL;
	}
}
array_t create_number_array(array_t integer_part, array_t fractional_part) {
	array_t new_list = map_multiple(functie_2,sizeof(number_t),destructor,2,integer_part,fractional_part);
	return new_list;
}

boolean functie_3(void *p)
{
	student_t stud = *(student_t *)p;
	return stud.grade > 5.0;
}

array_t get_passing_students_names(array_t list) {
	array_t new_list = filter(functie_3 , list);
	return new_list;
}


void functie_4(void *acc , void *lista_valori)
{
	int suma = 0;
	for(int i=0;i<(*(array_t *)lista_valori).len;i++)
		suma+=*(int *)((*(array_t *)lista_valori).data+i*(*(array_t *)lista_valori).elem_size);
	memcpy(acc,&suma,sizeof(int));
}

void verificare(void *element_lista_noua,void **lista_valori)
{
	boolean *value = (boolean *)element_lista_noua;
	int elem_sume = *(int *)lista_valori[0];
	int elem_control = *(int *)lista_valori[1];
	if(elem_sume >= elem_control)
		*value = true;
	else 
		*value = false;
}

array_t check_bigger_sum(array_t list_list, array_t int_list) {
	
	
	array_t new_list_sums = map(functie_4 , sizeof(int) , int_list.destructor , list_list);
	array_t new_list = map_multiple(verificare,sizeof(boolean),NULL,2,new_list_sums,int_list);
	return new_list;
}

void inc_elem(void *elem)
{
	int *i = (int *)elem;
	if(*(i-1)!=0)
		(*i)=*(i-1)+1;
}

void decr(void *elem)
{
	int *i = (int *)elem;
	(*i)--;
}



void functie_6(void *element_curent,void *sir_curent)
{
	array_t *adr_list = (array_t *)element_curent;
	char *adr_sir_curent = (char *)sir_curent;
	if((adr_sir_curent - (char *)adr_list->data)/adr_list->elem_size % 2 == 1)
	{
			adr_list->destructor(sir_curent);
			strcpy(adr_sir_curent , "*");
	}
}

boolean verif(void *adr_sir)
{
	return strcmp((char *)adr_sir,"*") != 0 ? 1:0;
}


array_t get_even_indexed_strings(array_t list) {

	reduce(functie_6,&list,list);
	array_t new_list = filter(verif,list);
	return new_list;
}

void destructor_string(void *string)
{
	free(*(char **)string);
}

void set_lenght(void *elem)
{
	int *i = (int *)elem;
	if(*(i-1)!=0)
		(*i)=*(i-1);
}

void destructor_array(void *p)
{
	array_t *elem = (array_t *)p;
	if((*elem).data!=NULL)
	{
		free((*elem).data);
	}
}

void functie_5(void *new_list , void **old_elemet)
{
	array_t Array;
	array_t *lista_new = (array_t *)new_list;
	Array.len = *(int *)old_elemet[1];
	Array.elem_size = sizeof(int);
	Array.destructor = NULL;
	Array.data = malloc(Array.elem_size*Array.len);
	*((int *)Array.data) = *(int *)old_elemet[0];
	for_each(inc_elem,Array); 
	(*lista_new).len=Array.len;
	(*lista_new).elem_size=sizeof(int);
	(*lista_new).destructor =NULL;
	(*lista_new).data = malloc((*lista_new).len*(*lista_new).elem_size);
	for(int i=0;i<(*lista_new).len;i++)
	{
		
		*(int *)((*lista_new).data+i*(*lista_new).elem_size)=*(int *)(Array.data+i*Array.elem_size);
	}
}

array_t generate_square_matrix(int n) {
	array_t Array,Lenght;
	Array.len = n;
	Lenght.len = n;
	Array.elem_size = sizeof(int);
	Lenght.elem_size = sizeof(int);
	Array.destructor = NULL;
	Lenght.destructor =NULL;
	Array.data = malloc(Array.elem_size*Array.len);
	Lenght.data = malloc(Lenght.elem_size*Lenght.len);
	*((int *)Array.data) = 1;
	*((int *)Lenght.data) = Lenght.len;
	for_each(inc_elem,Array); 
	for_each(set_lenght,Lenght);
	array_t new_array = map_multiple(functie_5,sizeof(array_t), destructor_array, 2, Array,Lenght);

	return new_array;
}
